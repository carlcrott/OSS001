Jordan Miller
peptides@benchscience.org
2010-12-05

Licensed under CC BY-NC-SA
http://www.thingiverse.com/thing:5045

Here is my entry to the Open Call for Open Science Equipment Contest, detailed here:
thecitizensciencequarterly.com/2010/11/25/open-call-for-open-science-equipment/

Start with the video to see what this is all about:
youtube.com/watch?v=1d4_SQBTFjg
vimeo.com/17497511

Download the .zip file to get everything, or get the individual pieces you want.

This is an open-source orbital shaker for mammalian cell and tissue culture and for bench-top science. The orbital shaker fits inside a standard 37 ºC/5% CO2 cell incubator and puts out no heat so you can load up the incubator full of these things. We have used them for 2 weeks now and the design is very simple, inexpensive, and scaleable. Our cells are growing happily in these shakers.

Orbital shakers are typically ~$1,500 and even more expensive if you need one that is designed for a cell incubator so that it will not put out any heat (incubators only have heating and not cooling functions, so if equipment puts out too much heat it will kill all the cells in the incubator).

To accomplish this goal I used an arduino microcontroller, Pololu stepper motor controller, and an inexpensive stepper motor. A DC motor could have been used but it is very difficult to control the rotational speed with high accuracy since the DC motor rotation speed varies based on load. Instead I used a $10 stepper motor and a pololu stepper motor controller at 1/16th stepping.

I used 3D printed parts I designed and printed with a MakerBot to make the off-axis motor connector and bearing plate holder.

Nuts and bolts are used to finish the design.

Stepper motors are known to put out enormous vibrations, so part of the design also required rubber tubing stand-offs which smooth out the motion of the orbital shaker and also dampen all of the motor vibration.

Coding the stepper motor rotational speed was straightforward once we calibrated the correct delay time between motor steps. We typically run the shakers at 2 Hz (2 revolutions per second) but can easily get anywhere from 0.2-5 Hz with the current setup.

Full sources are available on Thingiverse, posted today.

Typical orbital shaker: $1500

Cost Breakdown for Open Source Orbital Shaker:
First shaker minimum requirements to get started:
ATX Power Supply $30
Arduino $30
USB plug and long cable $20
Motor $10
Bearing $1
Tubing $1
Motor controller $40
Wire $4
Nuts and Bolts $5
3D printed parts $0.50
Total: $141.50

Additional shakers, incremental requirements:
Motor $10
Bearing $1
Tubing $1
Motor controller $40
Wire $4
Nuts and Bolts $5
3D printed parts $0.50
Total Incremental cost for each additional shaker: $61.50

Currently we have 4 shakers being driven concurrently with this setup (one set of electronics).

And here (attached) is a video of them working in our incubator!

My design would benefit from winning this contest by being able to design a lasercut case for the electronics and make a kit that could be purchased directly by customers. I would make the 3D printed parts lasercut instead to make mass production easier.

All of these parts are sourceable from SparkFun and Ponoko. The motor controller I used is not from SparkFun but SparkFun has many that would work for this application, or they may be willing to sell the controller that I am using (from JohnYang.com).

This orbital shaker is likely to have numerous applications in bench-top science in addition to in vitro cell culture.
Instructions

Print one PlateSlab and one MotorShaftHolder
Get some tubing. The tubing for the motor shaft holder has to be 8 mm OD (outer diameter) to exactly fit inside the 608 skate bearing.

Screw 50 mm M3 socket cap bolt fixed in place on the motor shaft holder.
Then put Small piece tubing on motor shaft (will prevent holder from sliding down the motor shaft). Then put on motor shaft holder. Then put more tubing on the socket cap of the 50 mm bolt. The tubing dampens the vibrations from the motor.

To get the bearing into the plate slab you may want to hold it in a flame for a while to heat it up. Then it will melt in and get a really nice press-fit.

Use small M3 socket cap bolts in the motor housing. 8-12 mm work well. You want the socket caps to stick up above the motor housing so that the tubing can grip it easily.

Use small M3 socket cap bolts in the PlateSlab. 12 mm work well here also. Connect all tubing.

Wire up the motor. Program the arduino (see the .pde, attached to this thing). Plug everything in. Turn on the ATX power supply. The motors will slowly accelerate during the first rotation to get up to full speed (so you don't spill cell media everywhere). The current .pde drives the 1/16th stepped motors at 2 Hz (2 revolutions per second).

Required Tools

	 3D Printer 	 Hot Glue Gun 	 Soldering Iron 	 Wire Cutters 	 Wire Strippers
